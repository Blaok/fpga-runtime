﻿#ifndef FPGA_RUNTIME_H_
#define FPGA_RUNTIME_H_

#include <cstddef>

#include <algorithm>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#define CL_HPP_CL_1_2_DEFAULT_BUILD
#define CL_HPP_TARGET_OPENCL_VERSION 120
#define CL_HPP_MINIMUM_OPENCL_VERSION 120
#include <CL/cl2.hpp>

#include "opencl-errors.h"

extern "C" {
struct _cl_stream;
}  // extern "C"

namespace fpga {
namespace internal {

#ifdef KEEP_CL_CHECK
#define CL_CHECK(err) ::fpga::internal::ClCheck((err), __FILE__, __LINE__);
#endif  // KEEP_CL_CHECK

inline void ClCheck(cl_int err, const char* file, int line) {
  if (err != CL_SUCCESS) {
    throw std::runtime_error(std::string(file) + ":" + std::to_string(line) +
                             ": " + ToString(err));
  }
}

template <typename T>
class Buffer {
  T* ptr_;
  size_t n_;

 public:
  Buffer(T* ptr, size_t n) : ptr_(ptr), n_(n) {}
  operator T*() const { return ptr_; }
  T& operator*() const { return *ptr_; }
  T* operator->() const { return ptr_; }
  T* Get() const { return ptr_; }
  size_t SizeInBytes() const { return n_ * sizeof(T); }
};

class Stream {
 protected:
  const std::string name_;
  _cl_stream* stream_ = nullptr;
  cl::Kernel kernel_;
  cl::Device device_;

  Stream(const std::string& name) : name_(name) {}
  Stream(const Stream&) = delete;
  ~Stream();

  void Attach(const cl::Device& device, const cl::Kernel& kernel, int index,
              /* cl_stream_flags */ uint64_t flags);
};

}  // namespace internal

template <typename T>
class ReadOnlyBuffer : public internal::Buffer<T> {
  using internal::Buffer<T>::Buffer;
};
template <typename T>
class WriteOnlyBuffer : public internal::Buffer<T> {
  using internal::Buffer<T>::Buffer;
};
template <typename T>
class ReadWriteBuffer : public internal::Buffer<T> {
  using internal::Buffer<T>::Buffer;
};
template <typename T>
class PlaceholderBuffer : public internal::Buffer<T> {
  using internal::Buffer<T>::Buffer;
};
template <typename T>
ReadOnlyBuffer<T> ReadOnly(T* ptr, size_t n) {
  return ReadOnlyBuffer<T>(ptr, n);
}
template <typename T>
WriteOnlyBuffer<T> WriteOnly(T* ptr, size_t n) {
  return WriteOnlyBuffer<T>(ptr, n);
}
template <typename T>
ReadWriteBuffer<T> ReadWrite(T* ptr, size_t n) {
  return ReadWriteBuffer<T>(ptr, n);
}
template <typename T>
PlaceholderBuffer<T> Placeholder(T* ptr, size_t n) {
  return PlaceholderBuffer<T>(ptr, n);
}

class ReadStream : public internal::Stream {
 public:
  using internal::Stream::Attach;
  ReadStream(const std::string& name) : internal::Stream(name) {}
  ReadStream(const ReadStream&) = delete;

  void Attach(const cl::Device& device, const cl::Kernel& kernel, int index);

  template <typename T>
  void Read(T* host_ptr, uint64_t size, bool eos = true) {
    ReadRaw(host_ptr, size * sizeof(T), eos);
  }

 private:
  void ReadRaw(void* host_ptr, uint64_t size, bool eos);
};

class WriteStream : public internal::Stream {
 public:
  using internal::Stream::Attach;
  WriteStream(const std::string& name) : internal::Stream(name) {}
  WriteStream(const WriteStream&) = delete;

  void Attach(cl::Device device, cl::Kernel kernel, int index);

  template <typename T>
  void Write(const T* host_ptr, uint64_t size, bool eos = true) {
    WriteRaw(host_ptr, size * sizeof(T), eos);
  }

 private:
  void WriteRaw(const void* host_ptr, uint64_t size, bool eos);
};

struct ArgInfo {
  enum Cat {
    kScalar = 0,
    kMmap = 1,
    kStream = 2,
  };
  int32_t index;
  std::string name;
  std::string type;
  Cat cat;
  std::string tag;
};

inline std::ostream& operator<<(std::ostream& os, const ArgInfo::Cat& cat) {
  switch (cat) {
    case ArgInfo::kScalar:
      return os << "scalar";
    case ArgInfo::kMmap:
      return os << "mmap";
    case ArgInfo::kStream:
      return os << "stream";
  }
  return os;
}

inline std::ostream& operator<<(std::ostream& os, const ArgInfo& arg) {
  os << "ArgInfo: {index: " << arg.index << ", name: ‘" << arg.name
     << "’, type: ‘" << arg.type << "’, category: " << arg.cat;
  if (!arg.tag.empty()) os << ", tag: ‘" << arg.tag << "’";
  os << "}";
  return os;
}

enum class Vendor {
  kUnknown = 0,
  kXilinx = 1,
  kIntel = 2,
};

class Instance {
  cl::Device device_;
  cl::Context context_;
  cl::CommandQueue cmd_;
  cl::Program program_;
  // Maps prefix sum of arg count to kernels.
  std::map<int, cl::Kernel> kernels_;
  std::unordered_map<int, cl::Buffer> buffer_table_;
  std::unordered_map<int, void*> host_ptr_table_;
  std::unordered_map<int32_t, ArgInfo> arg_table_;
  std::unordered_set<int> load_indices_;
  std::unordered_set<int> store_indices_;
  std::vector<cl::Event> load_event_;
  std::vector<cl::Event> compute_event_;
  std::vector<cl::Event> store_event_;
  Vendor vendor_ = Vendor::kUnknown;

  std::vector<cl::Memory> GetLoadBuffers();
  std::vector<cl::Memory> GetStoreBuffers();
  std::pair<int, cl::Kernel> GetKernel(int index) {
    auto it = --this->kernels_.upper_bound(index);
    return {index - it->first, it->second};
  }
  template <typename T>
  void SetArgInternal(int index, T arg) {
    auto pair = this->GetKernel(index);
    pair.second.setArg(pair.first, arg);
  }

 public:
  Instance(const std::string& bitstream);

  // Return info of all args as a vector, sorted by the index.
  std::vector<ArgInfo> GetArgsInfo() {
    std::vector<ArgInfo> args;
    args.reserve(arg_table_.size());
    for (const auto& arg : arg_table_) {
      args.push_back(arg.second);
    }
    std::sort(args.begin(), args.end(),
              [](const ArgInfo& lhs, const ArgInfo& rhs) {
                return lhs.index < rhs.index;
              });
    return args;
  }

#ifdef NDEBUG
#define FUNC_INFO(index)
#else  // NDEBUG
#define FUNC_INFO(index)                                  \
  std::clog << "DEBUG: Function ‘" << __PRETTY_FUNCTION__ \
            << "’ called with index = " << (index) << std::endl;
#endif  // NDEBUG

  // SetArg
  template <typename T>
  void SetArg(int index, T&& arg) {
    FUNC_INFO(index)
    this->SetArgInternal(index, arg);
  }
  template <typename T>
  void SetArg(int index, ReadOnlyBuffer<T> arg) {
    FUNC_INFO(index)
    this->SetArgInternal(index, buffer_table_[index]);
  }
  template <typename T>
  void SetArg(int index, WriteOnlyBuffer<T> arg) {
    FUNC_INFO(index)
    this->SetArgInternal(index, buffer_table_[index]);
  }
  template <typename T>
  void SetArg(int index, ReadWriteBuffer<T> arg) {
    FUNC_INFO(index)
    this->SetArgInternal(index, buffer_table_[index]);
  }
  template <typename T>
  void SetArg(int index, PlaceholderBuffer<T> arg) {
    FUNC_INFO(index)
    this->SetArgInternal(index, buffer_table_[index]);
  }
  void SetArg(int index, WriteStream& arg) { FUNC_INFO(index) }
  void SetArg(int index, ReadStream& arg) { FUNC_INFO(index) }
  template <typename T, typename... Args>
  void SetArg(int index, T&& arg, Args&&... other_args) {
    SetArg(index, std::forward<T>(arg));
    SetArg(index + 1, std::forward<Args>(other_args)...);
  }
  template <typename... Args>
  void SetArg(Args&&... args) {
    SetArg(0, std::forward<Args>(args)...);
  }

  cl::Buffer CreateBuffer(int index, cl_mem_flags flags, size_t size,
                          void* host_ptr);

  // AllocBuf
  template <typename T>
  void AllocBuf(int index, T&& arg) {
    FUNC_INFO(index)
  }
  template <typename T>
  void AllocBuf(int index, WriteOnlyBuffer<T> arg) {
    FUNC_INFO(index)
    cl::Buffer buffer = CreateBuffer(
        index, CL_MEM_WRITE_ONLY, arg.SizeInBytes(),
        const_cast<typename std::remove_const<T>::type*>(arg.Get()));
    load_indices_.insert(index);
  }
  template <typename T>
  void AllocBuf(int index, ReadOnlyBuffer<T> arg) {
    FUNC_INFO(index)
    cl::Buffer buffer =
        CreateBuffer(index, CL_MEM_READ_ONLY, arg.SizeInBytes(), arg.Get());
    store_indices_.insert(index);
  }
  template <typename T>
  void AllocBuf(int index, ReadWriteBuffer<T> arg) {
    FUNC_INFO(index)
    cl::Buffer buffer =
        CreateBuffer(index, CL_MEM_READ_WRITE, arg.SizeInBytes(), arg.Get());
    load_indices_.insert(index);
    store_indices_.insert(index);
  }
  template <typename T>
  void AllocBuf(int index, PlaceholderBuffer<T> arg) {
    FUNC_INFO(index)
    cl::Buffer buffer = CreateBuffer(index, 0, arg.SizeInBytes(), arg.Get());
  }
  void AllocBuf(int index, WriteStream& arg) {
    FUNC_INFO(index)
    auto pair = this->GetKernel(index);
    arg.Attach(device_, pair.second, pair.first);
  }
  void AllocBuf(int index, ReadStream& arg) {
    FUNC_INFO(index)
    auto pair = this->GetKernel(index);
    arg.Attach(device_, pair.second, pair.first);
  }

  template <typename T, typename... Args>
  void AllocBuf(int index, T&& arg, Args&&... other_args) {
    AllocBuf(index, std::forward<T>(arg));
    AllocBuf(index + 1, std::forward<Args>(other_args)...);
  }
  template <typename... Args>
  void AllocBuf(Args&&... args) {
    AllocBuf(0, std::forward<Args>(args)...);
  }
#undef FUNC_INFO

  // Suspends a buffer from being transferred between host and device.
  size_t SuspendBuf(int index);

  void WriteToDevice();
  void ReadFromDevice();
  void Exec();
  void Finish();

  template <typename... Args>
  Instance& Invoke(Args&&... args) {
    AllocBuf(std::forward<Args>(args)...);
    SetArg(std::forward<Args>(args)...);
    WriteToDevice();
    Exec();
    ReadFromDevice();
    bool has_stream = false;
    bool dummy[sizeof...(Args)]{(
        has_stream |=
        std::is_base_of<internal::Stream,
                        typename std::remove_reference<Args>::type>::value)...};
    if (!has_stream) {
#ifndef NDEBUG
      std::clog << "DEBUG: no stream found; waiting for command to finish"
                << std::endl;
#endif
      Finish();
    }
    return *this;
  }

  cl_ulong LoadTimeNanoSeconds();
  cl_ulong ComputeTimeNanoSeconds();
  cl_ulong StoreTimeNanoSeconds();
  double LoadTimeSeconds();
  double ComputeTimeSeconds();
  double StoreTimeSeconds();
  double LoadThroughputGbps();
  double StoreThroughputGbps();
};

template <typename... Args>
Instance Invoke(const std::string& bitstream, Args&&... args) {
  return Instance(bitstream).Invoke(std::forward<Args>(args)...);
}

}  // namespace fpga

#endif  // FPGA_RUNTIME_H_
